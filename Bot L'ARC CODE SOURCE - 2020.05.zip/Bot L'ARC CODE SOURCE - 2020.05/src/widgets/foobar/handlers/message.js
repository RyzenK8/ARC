module.exports = async message => {
  console.log('foobar: message');
};
