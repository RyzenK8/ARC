module.exports = async (messageReaction, user) => {
  console.log('foobar: messageReactionAdd');
};
