module.exports = ({ type }) => type === 'text';
