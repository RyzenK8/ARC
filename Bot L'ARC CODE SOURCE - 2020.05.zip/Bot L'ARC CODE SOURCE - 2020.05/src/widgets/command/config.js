module.exports = {
  prefixes: ['.'],
  commandDelimiter: ',,',
  commandLimit: 3,
  owners: ['206161807491072000']
};
